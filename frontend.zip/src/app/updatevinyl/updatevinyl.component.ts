import { Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ApiserviceService} from '../apiservice.service';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-updatevinyl',
  templateUrl: './updatevinyl.component.html',
  styleUrls: ['./updatevinyl.component.css']
})
export class UpdatevinylComponent implements OnInit {

  vinylForm = new FormGroup({
    'album':new FormControl('',Validators.required),
    'artist':new FormControl('',Validators.required),
    'genre':new FormControl('',Validators.required),
    'producer':new FormControl('',Validators.required),
    'length':new FormControl('',Validators.required),
    'oriPrice':new FormControl('',Validators.required),
    'marketPrice':new FormControl('',Validators.required)
//album, artist, genre, producer, length, oriPrice, marketPrice

  });

  constructor(private service:ApiserviceService,  private router:ActivatedRoute) { }

  errormsg:any;
  successmsg:any;
  getparamid:any;
  message: boolean= false;

  ngOnInit(): void {

      this.service.getOnevinyl(this.router.snapshot.params['id']).subscribe((res:any)=>{
        console.log(res,'res==>');
        this.vinylForm.patchValue({
          album:res.data[0].album,
          artist:res.data[0].artist,
          genre:res.data[0].genre,
          producer:res.data[0].producer,
          length:res.data[0].length,
          oriPrice:res.data[0].oriPrice,
          marketPrice:res.data[0].marketPrice

        });
      });
  }
//to update a vinyl
vinylUpdate()
{
  console.log(this.vinylForm.value);
    this.service.updatevinyl(this.router.snapshot.params['id'], this.vinylForm.value).subscribe((result:any)=>{

    this.vinylForm.reset();
    this.successmsg = 'Album updated successfully!';
    this.message = true;

    });
  }
removeMessage(){
  this.message = false;
}
}
