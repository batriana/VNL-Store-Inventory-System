import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatevinylComponent } from './updatevinyl.component';

describe('UpdatevinylComponent', () => {
  let component: UpdatevinylComponent;
  let fixture: ComponentFixture<UpdatevinylComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatevinylComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatevinylComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
