import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { FaqComponent } from './faq/faq.component';
import { UpdatevinylComponent } from './updatevinyl/updatevinyl.component';
import { ViewvinylComponent } from './viewvinyl/viewvinyl.component';
import { AddvinylComponent } from './addvinyl/addvinyl.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'aboutus', component: AboutusComponent },
  { path: 'faq', component: FaqComponent },
  { path: 'updatevinyl/:id', component: UpdatevinylComponent },
  { path: 'viewvinyl', component: ViewvinylComponent },
  { path: 'addvinyl', component: AddvinylComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


