import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
const basevinylUrl = "http://localhost:8080/vinyl"
const createvinylUrl = "http://localhost:8080/vinyl/add"
const delvinylUrl = "http://localhost:8080/vinyl/del"
const putvinylUrl = "http://localhost:8080/vinyl/put"

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
 
  constructor(private _http:HttpClient) { }
//get all 
getAllvinyl():Observable<any>{
  const url = "http://localhost:8080/allvinyl"
  return this._http.get<any>(url)
}

 // create
 createvinyl(vinyl: any):Observable<any>{
  console.log(vinyl,'createapi=>');
  return this._http.post(createvinylUrl, vinyl)
}

//deleting 

deletevinyl(id: any): Observable<any> {
  return this._http.delete(`${delvinylUrl}/${id}`);

}

//update 
updatevinyl(id: any, vinyl: any): Observable<any> {
  return this._http.put(`${putvinylUrl}/${id}`, vinyl);

}

//get one 
getOnevinyl(id:any):Observable<any>{
  return this._http.get(`${basevinylUrl}/${id}`);
}

}
