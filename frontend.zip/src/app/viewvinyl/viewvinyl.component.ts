import { Component, OnInit } from '@angular/core';
import {ApiserviceService}from '../apiservice.service';

@Component({
  selector: 'app-viewvinyl',
  templateUrl: './viewvinyl.component.html',
  styleUrls: ['./viewvinyl.component.css']
})
export class ViewvinylComponent implements OnInit {

  constructor(private service:ApiserviceService) { }


  listData:any;
  successmsg:any;


ngOnInit(): void {
  this.getAllvinyl();


  }

  //get delete id
  deleteId(id:any){
    console.log(id,'deleteid==>');
    this.service.deletevinyl(id).subscribe((res: any)=>{
      console.log(res,'deleteres==>');
      this.successmsg = "Album deleted successfully!";
      this.getAllvinyl();

    });

  }

  //get vinyl
  getAllvinyl(){

    this.service.getAllvinyl().subscribe((res: { data: any; })=>{
      console.log(res,"res==>");

      this.listData = res.data;
    });

  }

}
