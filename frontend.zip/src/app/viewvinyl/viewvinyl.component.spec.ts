import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewvinylComponent } from './viewvinyl.component';

describe('ViewvinylComponent', () => {
  let component: ViewvinylComponent;
  let fixture: ComponentFixture<ViewvinylComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewvinylComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewvinylComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
