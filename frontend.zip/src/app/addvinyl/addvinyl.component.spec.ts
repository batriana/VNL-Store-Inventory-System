import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddvinylComponent } from './addvinyl.component';

describe('AddvinylComponent', () => {
  let component: AddvinylComponent;
  let fixture: ComponentFixture<AddvinylComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddvinylComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddvinylComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
