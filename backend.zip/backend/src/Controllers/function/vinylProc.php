<?php 
//get all vinyl 
function getAllVinyl($db) {

    
    $sql = 'Select * FROM vinyl'; 
    $stmt = $db->prepare ($sql); 
    $stmt ->execute(); 
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 
} 

//get vinyl by id 
function getvinyl($db, $vinylId) {

    $sql = 'Select o.album, o.artist, o.genre, o.producer, o.length, o.oriPrice, o.marketPrice FROM vinyl o  ';
    $sql .= 'Where o.id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int) $vinylId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 

}

//add new vinyl 
function createvinyl($db, $form_data) { 
    //stop at sisni
    $sql = 'Insert into vinyl ( album, artist, genre, producer, length, oriPrice, marketPrice)'; 
    $sql .= 'values (:album, :artist, :genre, :producer, :length, :oriPrice, :marketPrice)';  
    $stmt = $db->prepare ($sql); 
    $stmt->bindParam(':album', ($form_data['album']));
    $stmt->bindParam(':artist', ($form_data['artist']));
    $stmt->bindParam(':genre', ($form_data['genre']));
    $stmt->bindParam(':producer', ($form_data['producer']));
    $stmt->bindParam(':length', ($form_data['length']));
    $stmt->bindParam(':oriPrice', ($form_data['oriPrice']));
    $stmt->bindParam(':marketPrice', ($form_data['marketPrice']));
    $stmt->execute(); 
    return $db->lastInsertID();
}


//delete vinyl by id 
function deletevinyl($db,$vinylId) { 

    $sql = ' Delete from vinyl where id = :id';
    $stmt = $db->prepare($sql);  
    $id = (int)$vinylId; 
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); 
    $stmt->execute(); 
} 

//update vinyl by id 
function updatevinyl($db,$form_data,$vinylId) { 

    //album, artist, genre, producer, length, oriPrice, marketPrice
    $sql = 'UPDATE vinyl SET album = :album , artist = :artist , genre = :genre , producer = :producer, length = :length, oriPrice = :oriPrice, marketPrice = :marketPrice'; 
    $sql .=' WHERE id = :id'; 
    $stmt = $db->prepare ($sql); 
    $id = (int)$vinylId;  
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);  
    $stmt->bindParam(':album', ($form_data['album']));
    $stmt->bindParam(':artist', ($form_data['artist']));
    $stmt->bindParam(':genre', ($form_data['genre']));
    $stmt->bindParam(':producer', ($form_data['producer']));
    $stmt->bindParam(':length', ($form_data['length']));
    $stmt->bindParam(':oriPrice', ($form_data['oriPrice']));
    $stmt->bindParam(':marketPrice', ($form_data['marketPrice']));
    $stmt->execute(); 
}